using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using UnityEngine;

public class Moving : MonoBehaviour
{
    public GameObject GO;
    void Update()
    {
        if (Input.GetKey(KeyCode.W))
        {
            GO.transform.position = new Vector3(GO.transform.position.x, GO.transform.position.y, GO.transform.position.z + 0.1f);
        }
        if (Input.GetKey(KeyCode.S))
        {
            GO.transform.position = new Vector3(GO.transform.position.x, GO.transform.position.y, GO.transform.position.z - 0.1f);
        }
    }
}
